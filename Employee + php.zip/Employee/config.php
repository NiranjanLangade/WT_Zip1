
<?php
$servername="localhost";
$username="root";
$password="";
$db = "mysql:host=localhost;dbname=emp";
$pdo=new PDO($db,$username,$password);
?>

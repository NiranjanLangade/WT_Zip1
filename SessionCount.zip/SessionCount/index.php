<?php
include 'session_limit.php';

// Your other PHP code goes here...

// Check if the user is logged in
if (!isset($_SESSION['user'])) {
    // Simulate a login by setting a user identifier in the session
    $_SESSION['user'] = 'example_user';
}

// Display the user's session ID
echo "Welcome, " . $_SESSION['user'] . "!<br>";
echo "Your Session ID: " . session_id() . "<br>";

// Your other application-specific code goes here...

?>

<?php
session_start();

// Initialize the 'active_sessions' array if not set
if (!isset($_SESSION['active_sessions'])) {
    $_SESSION['active_sessions'] = [];
}

// Check if the maximum number of sessions is reached
if (count($_SESSION['active_sessions']) >= 4) {
    echo "Max concurrent sessions reached. Please try again later.";
    exit;
}

// Add the current session to the list of active sessions
$_SESSION['active_sessions'][] = session_id();

// Your other PHP code goes here...
?>
